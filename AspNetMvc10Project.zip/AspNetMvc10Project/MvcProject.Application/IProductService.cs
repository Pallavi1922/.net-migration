using System.Collections.Generic;
using MvcProject.Domain;

namespace MvcProject.Application;
public interface IProductService
{
    IEnumerable<Product> GetAll();
    Product? GetById(int id);
    void Add(Product product);
    void Update(Product product);
    void Delete(int id);
}